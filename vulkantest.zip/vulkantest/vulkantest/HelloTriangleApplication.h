
#define GLFW_INCLUDE_VULKAN//That way GLFW will include its own definitions and automatically load the Vulkan header with it
#include <GLFW/glfw3.h>


//reporting and propagating errors
#include <iostream>
#include <stdexcept>

#include <cstring>
#include <vector>
//provides the EXIT_SUCCESS and EXIT_FAILURE macros
#include <cstdlib>

#include <optional>
class HelloTriangeApplication {
public:
	void run() {

		initWindow();
		initVulkan();
		mainLoop();
		cleanup();
		
	}
	

private:
	

			
#ifdef  NDEBUG
	const bool enableValidationLayers = false;
#else
	const bool enableValidationLayers = true;
#endif //  NDEBUG	
		
	bool checkValidationLayerSupport();
	std::vector<const char*> getRequiredExtension();

	
	

	void pickPhysicalDevice();
	void createInstance();	
	void setupDebugMessenger();

	void initWindow();	
	void initVulkan();	
	void mainLoop();	
	void cleanup();
};
