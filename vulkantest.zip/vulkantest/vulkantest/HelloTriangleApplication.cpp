#include "HelloTriangleApplication.h"
//create window just this
#include <iostream>

const uint32_t WIDTH = 800;
const uint32_t HEIGHT = 600;

GLFWwindow* window;

VkInstance instance;

VkDebugUtilsMessengerEXT debugMessenger;




//This struct should be passed to the vkCreateDebugUtilsMessengerEXT function to create the VkDebugUtilsMessengerEXT object

VkResult CreateDebugUtilsMessengerEXT(VkInstance instance, const VkDebugUtilsMessengerCreateInfoEXT* pCreateInfo, const VkAllocationCallbacks* pAllocator, VkDebugUtilsMessengerEXT* pDebugMessenger) {
	auto func = (PFN_vkCreateDebugUtilsMessengerEXT)vkGetInstanceProcAddr(instance, "vkCreateDebugUtilsMessengerEXT");
	if (func != nullptr) {
		return func(instance, pCreateInfo, pAllocator, pDebugMessenger);
	}
	else {
		return VK_ERROR_EXTENSION_NOT_PRESENT;
	}

}
//initialize vulkan
void HelloTriangeApplication::initVulkan()
{

	createInstance();
	setupDebugMessenger();
	pickPhysicalDevice();
	createLogicalDevice();
}

//which kind of messages you would like to see, because not all are necessarily (fatal) errors
//getRequiredExtensions function that will return the required list of extensions 
//based on whether validation layers are enabled or not.
// MESSAGE CALL BACK
std::vector<const char*> HelloTriangeApplication::getRequiredExtension()
{

	uint32_t glfwExtensionCount = 0;
	const char** glfwExtension;
	glfwExtension = glfwGetRequiredInstanceExtensions(&glfwExtensionCount);

	std::vector<const char*> extensions(glfwExtension, glfwExtension + glfwExtensionCount);

	if (enableValidationLayers) {
		extensions.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME);
	}
	return extensions;


}
//what debug CALL BACK !!!!!!!!!!!!!!!!!!! look like
static VKAPI_ATTR VkBool32 VKAPI_CALL debugCallback(
	VkDebugUtilsMessageSeverityFlagBitsEXT messageSeverity,
	VkDebugUtilsMessageTypeFlagsEXT messageType,
	const VkDebugUtilsMessengerCallbackDataEXT* pCallbackData,
	void* pUserData) {

	std::cerr << "validation layer: " << pCallbackData->pMessage << std::endl;

	return VK_FALSE;


}















const std::vector<const char*> validationLayers = {
		"VK_LAYER_KHRONOS_validation"
};





//function checkValidationLayerSupport that checks if all of the requested layers are available
bool HelloTriangeApplication::checkValidationLayerSupport()
{
	{
		uint32_t layerCount;

		//First list all of the available layers using the vkEnumerateInstanceLayerProperties function
		vkEnumerateInstanceLayerProperties(&layerCount, nullptr);


		std::vector<VkLayerProperties> availiableLayers(layerCount);
		vkEnumerateInstanceLayerProperties(&layerCount, availiableLayers.data());

		//return false; dont touch !

		//check if all of the layers in validationLayers exist in the availableLayers list
		for (const char* layerName : validationLayers) {
			bool layerFound = false;
			for (const auto& layerProperties : availiableLayers) {
				if (strcmp(layerName, layerProperties.layerName) == 0) {
					layerFound = true;
					break;
				}
			}
			if (!layerFound) {
				return false;
			}
		}
		return true;

	}
}



void populateDebugMessengerCreateInfo(VkDebugUtilsMessengerCreateInfoEXT& createInfo) {
	createInfo = {};
	createInfo.sType = VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT;
	createInfo.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_VERBOSE_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;
	createInfo.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;
	createInfo.pfnUserCallback = debugCallback;
}



/*********************************************PHYSICAL DEVICES AND QUEUE FAMILIES*************************************************************/


struct QueueFamilyIndices {
	//uint32_t graphicsFamily;
	std::optional<uint32_t> graphicsFamily;

	bool isComplete() {
		return graphicsFamily.has_value();
	}

};

QueueFamilyIndices findQueueFamilies(VkPhysicalDevice device) {
	QueueFamilyIndices indices;
	// Logic to find queue family indices to populate struct with
	//retrieving the list of queue families
	uint32_t queueFamilyCount = 0;
	vkGetPhysicalDeviceQueueFamilyProperties(device, &queueFamilyCount, nullptr);

	std::vector<VkQueueFamilyProperties> queueFamilies(queueFamilyCount);
	vkGetPhysicalDeviceQueueFamilyProperties(device, &queueFamilyCount, queueFamilies.data());



	int i = 0;
	for (const auto& queueFamily : queueFamilies) {
		if (queueFamily.queueFlags & VK_QUEUE_GRAPHICS_BIT) {
			indices.graphicsFamily = i;
		}

		if (indices.isComplete()) {
			break;
		}


		i++;
	}
	return indices;
}


//Now we need to evaluate each of themand check if they are suitable for the operations we want to perform,
//because not all graphics cards are created equal.
bool isDeviceSuitable(VkPhysicalDevice device) {
	QueueFamilyIndices indices = findQueueFamilies(device);

	
	return indices.isComplete();
}


//select a graphics card in the system that supports the features we need.
void HelloTriangeApplication::pickPhysicalDevice()
{

	//The graphics card that we'll end up selecting will be stored in a VkPhysicalDevice handle that is added as a new class member. 
	//This object will be implicitly destroyed when the VkInstance is destroyed, so we won't need to do anything new in the cleanup function.
	VkPhysicalDevice physicalDevice = VK_NULL_HANDLE;
	//Listing the graphics cards is very similar to listing extensionsand starts with querying just the number.
	uint32_t deviceCount = 0;
	vkEnumeratePhysicalDevices(instance, &deviceCount, nullptr);

	//If there are 0 devices with Vulkan support then there is no point going further.
	if (deviceCount == 0) {
		throw std::runtime_error("failed to find GPUs with Vulkan supports");
	}
	//Otherwise we can now allocate an array to hold all of the VkPhysicalDevice handles.
	std::vector<VkPhysicalDevice> devices(deviceCount);
	vkEnumeratePhysicalDevices(instance, &deviceCount, devices.data());

	//check if any of the physical devices meet the requirements that we'll add to that function.
	for (const auto& device : devices) {
		if (isDeviceSuitable(device)) {
			physicalDevice = device;
			break;
		}
	}

	if (physicalDevice == VK_NULL_HANDLE) {
		throw std::runtime_error("failed to find a suitable GPU!");
	}


	
	
}


/********************************************END OF PHYSICAL DEVICES AND QUEUE FAMILIES**********************************************/






VkDevice device;


//The creation of a logical device involves specifying a bunch of details in structs again, 
//of which the first one will be VkDeviceQueueCreateInfo. This structure describes the number of queues we want for a single queue family. 
//Right now we're only interested in a queue with graphics capabilities.
void createLogicalDevice() {
	QueueFamilyIndices indices = findQueueFamilies(physicalDevice);

	VkDeviceQueueCreateInfo queueCreateInfo{};
	queueCreateInfo.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
	queueCreateInfo.queueFamilyIndex = indices.graphicsFamily.value();
	queueCreateInfo.queueCount = 1;

	float queuePriority = 1.0f;
	queueCreateInfo.pQueuePriorities = &queuePriority;
}









// fill in a struct with some information about our application.This data is technically optional,
//but it may provide some useful information to the driver in order to optimize our specific application
void HelloTriangeApplication::createInstance()
{
	
		VkApplicationInfo appInfo{};
		appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
		appInfo.pApplicationName = "hello triangle";
		appInfo.pEngineName = "No Engine";
		appInfo.applicationVersion = VK_MAKE_VERSION(1, 0, 0);
		appInfo.engineVersion = VK_MAKE_VERSION(1, 0, 0);
		appInfo.apiVersion = VK_API_VERSION_1_0;

		

		//tells the Vulkan driver which global extensions and validation layers we want to use. 
		//Global here means that they apply to the entire program and not a specific device,
		VkInstanceCreateInfo createInfo{};
		createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
		createInfo.pApplicationInfo = &appInfo;
		
		

		uint32_t glwfExtensionCount = 0;
		const char** glfwExtensions;

		glfwExtensions = glfwGetRequiredInstanceExtensions(&glwfExtensionCount);

		createInfo.enabledExtensionCount = glwfExtensionCount;
		createInfo.ppEnabledExtensionNames = glfwExtensions;

		createInfo.enabledLayerCount = 0;

		//Pointer to struct with creation info, Pointer to custom allocator callbacks, always nullptr in this tutorial,
		//Pointer to the variable that stores the handle to the new object
		VkResult result = vkCreateInstance(&createInfo, nullptr, &instance);

		//show errors
		if (enableValidationLayers && !checkValidationLayerSupport()) {
			throw std::runtime_error("validation layers requested, but not available");
		}

		//modify the VkInstanceCreateInfo struct instantiation to include the validation layer names if they are enabled:
		if (enableValidationLayers) {
			createInfo.enabledLayerCount = static_cast<uint32_t>(validationLayers.size());
			createInfo.ppEnabledLayerNames = validationLayers.data();

		}
		else {
			createInfo.enabledLayerCount = 0;
		}

		//get requirement message callback
		auto extensions = getRequiredExtension();
		createInfo.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
		createInfo.ppEnabledExtensionNames = extensions.data();


		VkDebugUtilsMessengerCreateInfoEXT debugCreateInfo;
		if (enableValidationLayers) {
			createInfo.enabledLayerCount = static_cast<uint32_t>(validationLayers.size());
			createInfo.ppEnabledLayerNames = validationLayers.data();

			populateDebugMessengerCreateInfo(debugCreateInfo);
			createInfo.pNext = (VkDebugUtilsMessengerCreateInfoEXT*)&debugCreateInfo;
		}
		else {
			createInfo.enabledLayerCount = 0;

			createInfo.pNext = nullptr;
		}


		//The vkGetInstanceProcAddr function will return nullptr if the function couldn't be loaded. 
		//We can now call this function to create the extension object if it's available:
		if (vkCreateInstance(&createInfo, nullptr, &instance) != VK_SUCCESS) {
			throw std::runtime_error("failed to create instance!");
		}



	
}








//all ABOVE are the DebuggerS

//
/********************************************************************************************************************************************/
void HelloTriangeApplication::initWindow()
{

	glfwInit();

	//GLFW was originally designed to create an OpenGL context, we need to tell it to not create an OpenGL context with a subsequent call:
	glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);

	//disable resize window
	glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);

	//The fourth parameter allows you to optionally specify a monitor to open the window
	//on and the last parameter is only relevant to OpenGL.
	window = glfwCreateWindow(WIDTH, HEIGHT, "Vulkasfsdn", nullptr, nullptr);

	//return GLFW_TRUE;

}
/**********************************************************************************************************************************************/



/*****************************************************************************************************************************************************/
//telling Vulkan about the callback function

void HelloTriangeApplication::setupDebugMessenger()
{
	if (!enableValidationLayers)return;


	//VkDebugUtilsMessengerCreateInfoEXT createInfo{};
	//createInfo.sType = VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT;
	//createInfo.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_VERBOSE_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;
	//createInfo.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;
	//createInfo.pfnUserCallback = debugCallback;
	//createInfo.pUserData = nullptr; // Optional

	VkDebugUtilsMessengerCreateInfoEXT createInfo;
	populateDebugMessengerCreateInfo(createInfo);

	//The vkGetInstanceProcAddr function will return nullptr if the function couldn't be loaded.
	//We can now call this function to create the extension object if it's available:
	if (CreateDebugUtilsMessengerEXT(instance, &createInfo, nullptr, &debugMessenger) != VK_SUCCESS) {
		throw std::runtime_error("failed to set up debug messenger!");

	}
}

//To keep the application running until either an error occurs or the window is closed,
	//we need to add an event loop to the mainLoop function
void HelloTriangeApplication::mainLoop()
{
	

		//It loops and checks for events like pressing the X button until the window has been closed by the user.
		while (!glfwWindowShouldClose(window)) {
			glfwPollEvents();
		}
	
}



//The VkDebugUtilsMessengerEXT object also needs to be cleaned up with a call to vkDestroyDebugUtilsMessengerEXT.
//Similarly to vkCreateDebugUtilsMessengerEXT the function needs to be explicitly loaded.
void DestroyDebugUtilsMessengerEXT(VkInstance instance, VkDebugUtilsMessengerEXT debugMessenger, const VkAllocationCallbacks* pAllocator) {
	auto func = (PFN_vkDestroyDebugUtilsMessengerEXT)vkGetInstanceProcAddr(instance, "vkDestroyDebugUtilsMessengerEXT");
	if (func != nullptr) {
		func(instance, debugMessenger, pAllocator);
	}
}


//deallocate the resources
void HelloTriangeApplication::cleanup()
{
	if (enableValidationLayers) {
		DestroyDebugUtilsMessengerEXT(instance, debugMessenger, nullptr);
	}
		glfwDestroyWindow(window);
		vkDestroyInstance(instance, nullptr);
		glfwTerminate();
	
}

/*******************************************************************************************************************************************/



